import { Country, RemittanceService } from '@/types';

export const countries: Country[] = [
  { code: 'MX', name: { es: 'México', en: 'Mexico' }, flag: '🇲🇽', currency: 'MXN' },
  { code: 'GT', name: { es: 'Guatemala', en: 'Guatemala' }, flag: '🇬🇹', currency: 'GTQ' },
  { code: 'CO', name: { es: 'Colombia', en: 'Colombia' }, flag: '🇨🇴', currency: 'COP' },
  { code: 'SV', name: { es: 'El Salvador', en: 'El Salvador' }, flag: '🇸🇻', currency: 'USD' },
  { code: 'DO', name: { es: 'Rep. Dominicana', en: 'Dominican Rep.' }, flag: '🇩🇴', currency: 'DOP' },
  { code: 'PE', name: { es: 'Perú', en: 'Peru' }, flag: '🇵🇪', currency: 'PEN' },
  { code: 'HN', name: { es: 'Honduras', en: 'Honduras' }, flag: '🇭🇳', currency: 'HNL' },
  { code: 'EC', name: { es: 'Ecuador', en: 'Ecuador' }, flag: '🇪🇨', currency: 'USD' },
  { code: 'BR', name: { es: 'Brasil', en: 'Brazil' }, flag: '🇧🇷', currency: 'BRL' },
  { code: 'AR', name: { es: 'Argentina', en: 'Argentina' }, flag: '🇦🇷', currency: 'ARS' },
];

export const originCountries: Country[] = [
  { code: 'US', name: { es: 'Estados Unidos', en: 'United States' }, flag: '🇺🇸', currency: 'USD' },
  { code: 'CA', name: { es: 'Canadá', en: 'Canada' }, flag: '🇨🇦', currency: 'CAD' },
  { code: 'ES', name: { es: 'España', en: 'Spain' }, flag: '🇪🇸', currency: 'EUR' },
  { code: 'UK', name: { es: 'Reino Unido', en: 'United Kingdom' }, flag: '🇬🇧', currency: 'GBP' },
];

export const services: RemittanceService[] = [
  {
    id: 'wise',
    name: 'Wise',
    logo: '💎',
    color: '#9FE870',
    fees: { fixed: 1.50, percent: 0.50 },
    spreadPercent: 0.35,
    speed: { es: '1-2 días', en: '1-2 days' },
    deliveryMethods: ['bank'],
    cashbackPercent: 15,
    // Wise Affiliate Program: https://wise.com/partnerwise/affiliates
    affiliateUrl: 'https://wise.com/invite/dic/compararemesas',
  },
  {
    id: 'remitly',
    name: 'Remitly',
    logo: '🚀',
    color: '#1E88E5',
    fees: { fixed: 0, percent: 0 },
    spreadPercent: 1.20,
    speed: { es: 'Minutos', en: 'Minutes' },
    deliveryMethods: ['bank', 'cash', 'mobile'],
    cashbackPercent: 20,
    // Remitly Affiliate: https://www.remitly.com/us/en/affiliates
    affiliateUrl: 'https://remit.ly/compararemesas',
  },
  {
    id: 'xoom',
    name: 'Xoom',
    logo: '⚡',
    color: '#003087',
    fees: { fixed: 0, percent: 0 },
    spreadPercent: 1.80,
    speed: { es: 'Minutos', en: 'Minutes' },
    deliveryMethods: ['bank', 'cash'],
    cashbackPercent: 10,
    // Xoom/PayPal Affiliate
    affiliateUrl: 'https://www.xoom.com/?ref=compararemesas',
  },
  {
    id: 'westernunion',
    name: 'Western Union',
    logo: '🌐',
    color: '#FFDD00',
    fees: { fixed: 5.00, percent: 0 },
    spreadPercent: 2.50,
    speed: { es: 'Minutos', en: 'Minutes' },
    deliveryMethods: ['bank', 'cash'],
    cashbackPercent: 5,
    // WU Affiliate: Commission Junction / Impact
    affiliateUrl: 'https://www.westernunion.com/us/en/home.html',
  },
  {
    id: 'moneygram',
    name: 'MoneyGram',
    logo: '🔵',
    color: '#FF6B00',
    fees: { fixed: 1.99, percent: 0 },
    spreadPercent: 2.20,
    speed: { es: 'Minutos', en: 'Minutes' },
    deliveryMethods: ['bank', 'cash'],
    cashbackPercent: 8,
    // MoneyGram Affiliate
    affiliateUrl: 'https://www.moneygram.com/',
  },
  {
    id: 'sendwave',
    name: 'Sendwave',
    logo: '🌊',
    color: '#00D4AA',
    fees: { fixed: 0, percent: 0 },
    spreadPercent: 1.50,
    speed: { es: '1-2 días', en: '1-2 days' },
    deliveryMethods: ['mobile'],
    cashbackPercent: 12,
    affiliateUrl: 'https://www.sendwave.com/',
  },
  {
    id: 'dolarapp',
    name: 'DolarApp',
    logo: '💵',
    color: '#00C853',
    fees: { fixed: 0, percent: 0 },
    spreadPercent: 0.80,
    speed: { es: '1 día', en: '1 day' },
    deliveryMethods: ['bank'],
    cashbackPercent: 25,
    onlyCountries: ['MX', 'CO'],
    // DolarApp referral program
    affiliateUrl: 'https://dfrfrrt.onelink.me/mGNm/compararemesas',
  },
  {
    id: 'pangea',
    name: 'Pangea',
    logo: '🌎',
    color: '#4CAF50',
    fees: { fixed: 0, percent: 0 },
    spreadPercent: 1.10,
    speed: { es: 'Minutos', en: 'Minutes' },
    deliveryMethods: ['bank', 'cash'],
    cashbackPercent: 18,
    affiliateUrl: 'https://gopangea.com/?ref=compararemesas',
  },
];

// Default/fallback exchange rates (will be replaced by real-time data)
export const defaultRates: Record<string, number> = {
  MXN: 17.15,
  GTQ: 7.78,
  COP: 4150,
  USD: 1.00,
  DOP: 58.50,
  PEN: 3.72,
  HNL: 24.85,
  BRL: 5.05,
  ARS: 875.00,
};
